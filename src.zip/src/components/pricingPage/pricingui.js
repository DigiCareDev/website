import React, { useState } from "react";

function PricingUi() {
  const [activeTab, setActiveTab] = useState("Silver");

  const pricingData = {
    Silver: {
      title: "Silver Plan",
      appPrice: "₹499",
      webPrice: "₹699",
      features: [
        { name: "AI-based Face Recognition", app: false, web: false },
        { name: "Fraud Attendance Detection", app: false, web: false },
        { name: "Real-time Attendance Sync", app: false, web: true },
      ],
    },
    Gold: {
      title: "Gold Plan",
      appPrice: "₹999",
      webPrice: "₹1399",
      features: [
        { name: "AI-based Face Recognition", app: true, web: true },
        { name: "Fraud Attendance Detection", app: false, web: true },
        { name: "Real-time Attendance Sync", app: true, web: true },
      ],
    },
    Diamond: {
      title: "Diamond Plan",
      appPrice: "₹1999",
      webPrice: "₹2499",
      features: [
        { name: "AI-based Face Recognition", app: true, web: true },
        { name: "Fraud Attendance Detection", app: true, web: true },
        { name: "Real-time Attendance Sync", app: true, web: true },
      ],
    },
  };

  return (
    <>
      <div className="container mx-auto py-16 px-4 md:px-20">
        {/* Heading */}
        <div className="text-center mb-8">
          <h2 className="text-3xl font-semibold text-gray-800">Pricing</h2>
          <p className="text-lg text-gray-600 mt-4">
            Choose from DigiCare4u's offerings across Attendance, Payroll, and Live Tracking features.
          </p>
        </div>

        {/* Tab Selection */}
        <div className="flex justify-center space-x-2 mb-6 bg-white p-4">
          {["Silver", "Gold", "Diamond"].map((tab) => (
            <button
              key={tab}
              className={`py-2 px-5 rounded-lg font-medium text-sm transition-all duration-300 border shadow-md ${activeTab === tab
                  ? "bg-blue-600 text-white border-blue-700 scale-105"
                  : "bg-white text-gray-800 border-gray-300 hover:bg-gray-100"
                }`}
              onClick={() => setActiveTab(tab)}
            >
              {tab}
            </button>
          ))}
        </div>



        {/* Pricing Table */}
        <div className="border border-gray-800 rounded-xl overflow-hidden">
          <table className="table-auto w-full text-left text-lg border-collapse border border-gray-800">
            <thead className="bg-gray-100">
              <tr>
                <th className="p-4 border border-gray-800 text-left text-xl font-semibold">
                  <div className="flex items-center">
                    <div className="bg-blue-100 p-3 rounded-full mr-4">
                      <img
                        src="https://cdn-icons-png.flaticon.com/512/5550/5550516.png"
                        alt="Icon"
                        className="w-8 h-8"
                      />
                    </div>
                    <h2 className="text-2xl font-semibold">{pricingData[activeTab].title}</h2>
                  </div>
                </th>
                <th className="p-4 border border-gray-800 text-center">
                  <p>DigiCare4u App</p>
                  <p className="text-4xl text-blue-600">{pricingData[activeTab].appPrice}</p>
                  <p className="text-sm text-gray-600">per staff per year</p>
                </th>
                <th className="p-4 border border-gray-800 text-center">
                  <p>DigiCare4u App + Web</p>
                  <p className="text-4xl text-blue-600">{pricingData[activeTab].webPrice}</p>
                  <p className="text-sm text-gray-600">per staff per year</p>
                </th>
              </tr>
            </thead>
            <tbody>
              {pricingData[activeTab].features.map((feature, index) => (
                <tr key={index} className={index % 2 === 0 ? "bg-gray-50" : ""}>
                  <td className="p-4 border border-gray-800">{feature.name}</td>
                  <td className="p-4 border border-gray-800 text-center text-red-500">
                    {feature.app ? "✔" : "✘"}
                  </td>
                  <td className="p-4 border border-gray-800 text-center text-green-500">
                    {feature.web ? "✔" : "✘"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="border border-gray-800 rounded-xl overflow-hidden mt-10">
          <table className="table-auto w-full text-left text-lg border-collapse border border-gray-800">
            <thead className="bg-gray-100">
              <tr>
                <th className="p-4 border border-gray-800 text-left text-xl font-semibold">
                  <div className="flex items-center">
                    <div className="bg-blue-100 p-3 rounded-full mr-4">
                      <img
                        src="https://cdn-icons-png.flaticon.com/512/5550/5550516.png"
                        alt="Icon"
                        className="w-8 h-8"
                      />
                    </div>
                    <h2 className="text-2xl font-semibold">{pricingData[activeTab].title}</h2>
                  </div>
                </th>
                <th className="p-4 border border-gray-800 text-center">
                  <p>DigiCare4u App</p>
                  <p className="text-4xl text-blue-600">{pricingData[activeTab].appPrice}</p>
                  <p className="text-sm text-gray-600">per staff per year</p>
                </th>
                <th className="p-4 border border-gray-800 text-center">
                  <p>DigiCare4u App + Web</p>
                  <p className="text-4xl text-blue-600">{pricingData[activeTab].webPrice}</p>
                  <p className="text-sm text-gray-600">per staff per year</p>
                </th>
              </tr>
            </thead>
            <tbody>
              {pricingData[activeTab].features.map((feature, index) => (
                <tr key={index} className={index % 2 === 0 ? "bg-gray-50" : ""}>
                  <td className="p-4 border border-gray-800">{feature.name}</td>
                  <td className="p-4 border border-gray-800 text-center text-red-500">
                    {feature.app ? "✔" : "✘"}
                  </td>
                  <td className="p-4 border border-gray-800 text-center text-green-500">
                    {feature.web ? "✔" : "✘"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

export default PricingUi;
