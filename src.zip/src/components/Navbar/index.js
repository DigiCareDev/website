"use client";
import { useState } from "react";
import { ImMobile } from "react-icons/im";
import Link from "next/link";
import { usePathname } from "next/navigation"; // Import usePathname

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false); // State for mobile menu toggle
  const pathname = usePathname(); // Get the current path

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const isActive = (path) => pathname === path; // Check if a path is active

  return (
    <nav className="bg-white w-full mx-auto sticky top-0 z-50 shadow-md">
      <div className="container mx-auto flex justify-between items-center py-1">
        {/* Left Side Logo */}
        <div className="flex items-center">
          <Link href="/">
            <img
              src="/images/logo.jpg" // Replace with your logo URL
              alt="Logo"
              className="w-14 h-15 cursor-pointer rounded-md py-2" // 50x50
            />
          </Link>
        </div>

        {/* Navigation Links for desktop */}
        <div className={`hidden md:flex space-x-6`}>
          <Link href="/">
            <span
              className={`${
                isActive("/") ? "text-white bg-blue-500 px-3 py-2 rounded" : "text-gray-700 px-3 py-2"
          } hover:text-white hover:bg-blue-500 rounded-md`}
            >
              Home
            </span>
          </Link>
          <Link href="/about">
            <span
              className={`${
                isActive("/about") ? "text-white bg-blue-500 px-3 py-2 rounded" : "text-gray-700 px-3 py-2"
          } hover:text-white hover:bg-blue-500 rounded-md`}
            >
              About
            </span>
          </Link>
          <Link href="/pricing">
            <span
              className={`${
                isActive("/pricing") ? "text-white bg-blue-500 px-3 py-2 rounded" : "text-gray-700 px-3 py-2"
          } hover:text-white hover:bg-blue-500 rounded-md`}
            >
              Pricing
            </span>
          </Link>
          <Link href="/features">
            <span
              className={`${
                isActive("/features")
                  ? "text-white bg-blue-500 px-3 py-2 rounded" : "text-gray-700 px-3 py-2"
          } hover:text-white hover:bg-blue-500 rounded-md`}
            >
              Features
            </span>
          </Link>
          <Link href="/testimonials">
            <span
              className={`${
                isActive("/testimonials") ?
                 "text-white bg-blue-500 px-3 py-2 rounded" : "text-gray-700 px-3 py-2"
          } hover:text-white hover:bg-blue-500 rounded-md`}
            >
              Testimonials
            </span>
          </Link>
          <Link href="/blog">
            <span
              className={`${
                isActive("/blog") ? "text-white bg-blue-500 px-3 py-2 rounded" : "text-gray-700 px-3 py-2"
          } hover:text-white hover:bg-blue-500 rounded-md`}
            >
              Blog
            </span>
          </Link>
          <Link href="/contact">
            <span
              className={`${
                isActive("/contact") ? "text-white bg-blue-500 px-3 py-2 rounded" : "text-gray-700 px-3 py-2"
          } hover:text-white hover:bg-blue-500 rounded-md`}
            >
              Contact
            </span>
          </Link>
        </div>

        {/* Right Side Login Button and Mobile Menu Toggle */}
        <div className="flex items-center justify-between">
          <Link href="tel:+919876543210" className="mx-3">
            <button className="bg-blue-500 text-white px-4 py-2 rounded flex items-center space-x-2 hover:bg-blue-500 transition duration-200">
              <ImMobile />
              <span>Contact</span>
            </button>
          </Link>

          {/* Mobile Menu Toggle Button */}
          <div className="md:hidden">
            <button
              className="text-gray-700 focus:outline-none"
              onClick={toggleMenu}
            >
              <svg
                className="w-6 h-6"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M4 6h16M4 12h16m-7 6h7"
                ></path>
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation Links */}
      <div
        className={`md:hidden ${isMenuOpen ? "block" : "hidden"} space-y-4 p-4`}
      >
        <Link href="/">
          <span
           className={`${
            isActive("/") ? "text-white bg-blue-500 px-3 py-2 rounded" : "text-gray-700 px-3 py-2"
          } hover:text-white hover:bg-blue-500 rounded-md`}
          >
            Home
          </span>
        </Link>
        <Link href="/about">
          <span
            className={`${
              isActive("/about") ? "text-white bg-blue-500 px-3 py-2 rounded" : "text-gray-700 px-3 py-2"
            } hover:text-white hover:bg-blue-500 rounded-md`}
          >
            About
          </span>
        </Link>
        <Link href="/pricing">
          <span
            className={`${
              isActive("/pricing") ? "text-white bg-blue-500 px-3 py-2 rounded" : "text-gray-700 px-3 py-2"
            } hover:text-white hover:bg-blue-500 rounded-md`}
          >
            Pricing
          </span>
        </Link>
        <Link href="/testimonials">
          <span
            className={`${
              isActive("/testimonials") ? "text-white bg-blue-500 px-3 py-2 rounded" : "text-gray-700 px-3 py-2"
            } hover:text-white hover:bg-blue-500 rounded-md`}
          >
            Testimonials
          </span>
        </Link>
        <Link href="/blog">
          <span
            className={`${
              isActive("/blog") ? "text-white bg-blue-500 px-3 py-2 rounded" : "text-gray-700 px-3 py-2"
            } hover:text-white hover:bg-blue-500 rounded-md`}
          >
            Blog
          </span>
        </Link>
        <Link href="/contact">
          <span
            className={`${
              isActive("/contact") ? "text-white bg-blue-500 px-3 py-2 rounded" : "text-gray-700 px-3 py-2"
            } hover:text-white hover:bg-blue-500 rounded-md`}
          >
            Contact
          </span>
        </Link>
      </div>
    </nav>
  );
};

export default Navbar;
