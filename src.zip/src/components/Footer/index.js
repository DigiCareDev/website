import { Mail, Phone, MapPin, Facebook, Instagram, Linkedin, Twitter } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-blue-500 text-white py-8">
      <div className="container mx-auto grid grid-cols-1 md:grid-cols-4 gap-8 px-6">
        
        {/* About Us Section */}
        <div>
          <h3 className="text-lg font-bold border-b-2 border-white pb-2">ABOUT US</h3>
          <strong>Keep All Control for your Person in your hand</strong>
          <p className=" text-sm">
          Take full control of your personal assets empowers you to oversee and manage your personal assets with unmatched ease.
          </p>
        </div>

        {/* Links Section */}
        <div>
          <h3 className="text-lg font-bold border-b-2 border-white pb-2">LINKS</h3>
          <ul className="mt-3 space-y-2 text-sm">
            <li><a href="/about" className="hover:text-gray-300">› About</a></li>
            <li><a href="/contact" className="hover:text-gray-300">› Contact</a></li>
            <li><a href="/blog" className="hover:text-gray-300">› Blog</a></li>
            {/* <li><a href="#" className="hover:text-gray-300">› Career</a></li>
            <li><a href="#" className="hover:text-gray-300">› Development</a></li>
            <li><a href="#" className="hover:text-gray-300">› Portfolio</a></li> */}
            <li><a href="#" className="hover:text-gray-300">› Privacy Policy</a></li>
          </ul>
        </div>

        {/* Our Services Section */}
        <div>
          <h3 className="text-lg font-bold border-b-2 border-white pb-2">OUR SERVICES</h3>
          <ul className="mt-3 space-y-2 text-sm">
            <li>› Live Tracking</li>
            <li>› Task Schudale</li>
            <li>› Insights/Report</li>
            <li>› Alert</li>
            <li>› Family sharing</li>

          </ul>
        </div>

        {/* Contact Section */}
        <div>
          <h3 className="text-lg font-bold border-b-2 border-white pb-2">CONTACT</h3>
          <ul className="mt-3 space-y-2 text-sm">
            <li className="flex items-center space-x-2">
              <Mail className="w-5 h-5" /> <span>info@progatetechnology.com</span>
            </li>
            <li className="flex items-center space-x-2">
              <Phone className="w-5 h-5" /> <span>1800-8894-207 (Toll Free)</span>
            </li>
            <li className="flex items-center space-x-2">
              <Phone className="w-5 h-5" /> <span>+91-9305111069-73</span>
            </li>
            <li className="flex items-center space-x-2">
              <Phone className="w-5 h-5" /> <span>+91-7318000751-55</span>
            </li>
            <li className="flex items-center space-x-2">
              <MapPin className="w-5 h-5" /> 
              <span>07, Khasra No. 426SA, Laulai, Mallhaur, Lucknow - 226028</span>
            </li>
          </ul>
        </div>
      </div>

      {/* Footer Bottom */}
      <div className="flex justify-between items-center text-sm mt-6 border-t border-white pt-3 px-10">
       <div>
       © {new Date().getFullYear()} DigiCare4u. All rights reserved.
       </div>

        <div className="flex mt-3 space-x-3">
            <a href="https://x.com/digicare4uPGT" className="text-white hover:text-gray-300"><Twitter /></a>
            <a href="https://www.facebook.com/profile.php?id=61565180807792" className="text-white hover:text-gray-300"><Facebook /></a>
            <a href="https://www.instagram.com/digicare4u.pgt/" className="text-white hover:text-gray-300"><Instagram /></a>
            <a href="https://www.linkedin.com/company/digicare4u/" className="text-white hover:text-gray-300"><Linkedin /></a>
          </div>
      </div>

    </footer>
  );
};

export default Footer;
