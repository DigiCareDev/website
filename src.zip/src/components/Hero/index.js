'use client';
import Image from 'next/image';

const Hero = () => {
    return (
        <div className="container mx-auto px-4 my-10">
            {/* <div >
                <video 
                    className="w-full mt-1" 
                    controls 
                    poster="https://via.placeholder.com/800x400.png?text=Video+Preview"
                    autoPlay
                    loop
                    muted
                >
                    <source src="/video/tracking.mp4" type="video/mp4" />
                    Your browser does not support the video tag.
                </video>
            </div> */}
            <div className="flex flex-col md:flex-row items-center justify-between bg-white p-6 mx-auto w-full">
                <div className="md:w-2/3">
                    <h2 className="text-3xl font-bold text-black mt-5">
                        Track your <span className="text-blue-500">Caring</span>, <span className="text-blue-500">Loving</span> and <span className="text-blue-500">Employes</span>
                    </h2>
                    <p className="text-gray-600 mt-2 text-lg mt-5">
                        This approach will make sure that only the sign-up <br/>  page  is shown and any other route will  <br/> automatically redirect to it.
                    </p>
                    <div className="mt-7 flex space-x-3">
                        <button className="bg-blue-500 text-white px-4 py-2 rounded-lg shadow-md hover:bg-blue-500">Call now</button>
                        <button className="bg-gray-200 text-black px-4 py-2 rounded-lg shadow-md hover:bg-gray-300">Message</button>
                    </div>
                    <div className="mt-7 flex items-center space-x-2">
                        <span className="text-gray-600 font-medium">Available now</span>
                        <Image src="/images/android.png" alt="Android" width={30} height={30} />
                        <Image src="/images/android.png" alt="Android" width={30} height={30} />
                    </div>
                </div>
                <div className="md:w-1/3 mt-6 md:mt-0 flex justify-center mt-6">
                    <Image src="/images/livetracking.png" alt="Map" width={300} height={300} className="rounded-lg" />
                </div>
            </div>
        </div>
    );
};

export default Hero;